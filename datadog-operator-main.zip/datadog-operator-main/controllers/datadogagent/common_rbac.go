package datadogagent

import (
	"context"

	apicommon "github.com/DataDog/datadog-operator/apis/datadoghq/common"
	"github.com/DataDog/datadog-operator/controllers/datadogagent/common"
	componentdca "github.com/DataDog/datadog-operator/controllers/datadogagent/component/clusteragent"
	"github.com/DataDog/datadog-operator/controllers/datadogagent/feature/kubernetesstatecore"
	"github.com/DataDog/datadog-operator/controllers/datadogagent/object"
	"github.com/DataDog/datadog-operator/pkg/kubernetes"
	"github.com/DataDog/datadog-operator/pkg/kubernetes/rbac"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"

	datadoghqv1alpha1 "github.com/DataDog/datadog-operator/apis/datadoghq/v1alpha1"
	"github.com/DataDog/datadog-operator/pkg/controller/utils"
	"github.com/DataDog/datadog-operator/pkg/controller/utils/datadog"
	"github.com/go-logr/logr"
	corev1 "k8s.io/api/core/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	apiequality "k8s.io/apimachinery/pkg/api/equality"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/version"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
)

const secretBackendMultipleProvidersScript = "/readsecret_multiple_providers.sh"

// roleBindingInfo contains the required information to build a Cluster Role Binding
type roleBindingInfo struct {
	name               string
	roleName           string
	serviceAccountName string
}

// buildRoleBinding creates a RoleBinding object
func buildRoleBinding(dda *datadoghqv1alpha1.DatadogAgent, info roleBindingInfo, agentVersion string) *rbacv1.RoleBinding {
	return &rbacv1.RoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Labels:    object.GetDefaultLabels(dda, dda.Name, agentVersion),
			Name:      info.name,
			Namespace: dda.Namespace,
		},
		RoleRef: rbacv1.RoleRef{
			APIGroup: rbac.RbacAPIGroup,
			Kind:     rbac.RoleKind,
			Name:     info.roleName,
		},
		Subjects: []rbacv1.Subject{
			{
				Kind:      rbac.ServiceAccountKind,
				Name:      info.serviceAccountName,
				Namespace: dda.Namespace,
			},
		},
	}
}

// buildServiceAccount creates a ServiceAccount object
func buildServiceAccount(dda *datadoghqv1alpha1.DatadogAgent, name, agentVersion string) *corev1.ServiceAccount {
	return &corev1.ServiceAccount{
		ObjectMeta: metav1.ObjectMeta{
			Labels:    object.GetDefaultLabels(dda, dda.Name, agentVersion),
			Name:      name,
			Namespace: dda.Namespace,
		},
	}
}

// getEventCollectionPolicyRule returns the policy rule for event collection
func getEventCollectionPolicyRule(dda *datadoghqv1alpha1.DatadogAgent) rbacv1.PolicyRule {
	return rbacv1.PolicyRule{
		APIGroups: []string{rbac.CoreAPIGroup},
		Resources: []string{rbac.ConfigMapsResource},
		ResourceNames: []string{
			common.DatadogTokenOldResourceName, // Kept for backward compatibility with agent <7.37.0
			utils.GetDatadogTokenResourceName(dda),
		},
		Verbs: []string{rbac.GetVerb, rbac.UpdateVerb},
	}
}

func (r *Reconciler) createServiceAccount(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, name, agentVersion string) (reconcile.Result, error) {
	serviceAccount := buildServiceAccount(dda, name, agentVersion)
	if err := controllerutil.SetControllerReference(dda, serviceAccount, r.scheme); err != nil {
		return reconcile.Result{}, err
	}
	logger.V(1).Info("createServiceAccount", "serviceAccount.name", serviceAccount.Name, "serviceAccount.Namespace", serviceAccount.Namespace)
	event := buildEventInfo(serviceAccount.Name, serviceAccount.Namespace, serviceAccountKind, datadog.CreationEvent)
	r.recordEvent(dda, event)
	return reconcile.Result{Requeue: true}, r.client.Create(context.TODO(), serviceAccount)
}

func (r *Reconciler) createClusterRoleBindingFromInfo(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, info roleBindingInfo, agentVersion string) (reconcile.Result, error) {
	clusterRoleBinding := buildClusterRoleBinding(dda, info, agentVersion)
	return r.createClusterRoleBinding(logger, dda, clusterRoleBinding)
}

func (r *Reconciler) createClusterRoleBinding(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRoleBinding *rbacv1.ClusterRoleBinding) (reconcile.Result, error) {
	logger.V(1).Info("createClusterRoleBinding", "clusterRoleBinding.name", clusterRoleBinding.Name)
	event := buildEventInfo(clusterRoleBinding.Name, clusterRoleBinding.Namespace, clusterRoleBindingKind, datadog.CreationEvent)
	r.recordEvent(dda, event)
	err := r.client.Create(context.TODO(), clusterRoleBinding)
	return reconcile.Result{}, err
}

func (r *Reconciler) cleanupClusterRole(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, name string) (reconcile.Result, error) {
	clusterRole := &rbacv1.ClusterRole{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Name: name}, clusterRole)
	if err != nil {
		if errors.IsNotFound(err) {
			return reconcile.Result{}, nil
		}
		return reconcile.Result{}, err
	}

	if !isOwnerBasedOnLabels(dda, clusterRole.Labels) {
		return reconcile.Result{}, nil
	}

	logger.V(1).Info("deleteClusterRole", "clusterRole.name", clusterRole.Name, "clusterRole.Namespace", clusterRole.Namespace)
	event := buildEventInfo(clusterRole.Name, clusterRole.Namespace, clusterRoleKind, datadog.DeletionEvent)
	r.recordEvent(dda, event)
	return reconcile.Result{}, r.client.Delete(context.TODO(), clusterRole)
}

func (r *Reconciler) cleanupClusterRoleBinding(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, name string) (reconcile.Result, error) {
	clusterRoleBinding := &rbacv1.ClusterRoleBinding{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Name: name}, clusterRoleBinding)
	if err != nil {
		if errors.IsNotFound(err) {
			return reconcile.Result{}, nil
		}
		return reconcile.Result{}, err
	}

	if !isOwnerBasedOnLabels(dda, clusterRoleBinding.Labels) {
		return reconcile.Result{}, nil
	}

	logger.V(1).Info("deleteClusterRoleBinding", "clusterRoleBinding.name", clusterRoleBinding.Name, "clusterRoleBinding.Namespace", clusterRoleBinding.Namespace)
	event := buildEventInfo(clusterRoleBinding.Name, clusterRoleBinding.Namespace, clusterRoleBindingKind, datadog.DeletionEvent)
	r.recordEvent(dda, event)
	return reconcile.Result{}, r.client.Delete(context.TODO(), clusterRoleBinding)
}

func (r *Reconciler) cleanupServiceAccount(logger logr.Logger, client client.Client, dda *datadoghqv1alpha1.DatadogAgent, name string) (reconcile.Result, error) {
	serviceAccount := &corev1.ServiceAccount{}
	err := client.Get(context.TODO(), types.NamespacedName{Name: name}, serviceAccount)
	if err != nil {
		if errors.IsNotFound(err) {
			return reconcile.Result{}, nil
		}
		return reconcile.Result{}, err
	}
	if !CheckOwnerReference(dda, serviceAccount) {
		return reconcile.Result{}, nil
	}
	logger.V(1).Info("deleteServiceAccount", "serviceAccount.name", serviceAccount.Name, "serviceAccount.Namespace", serviceAccount.Namespace)
	event := buildEventInfo(serviceAccount.Name, serviceAccount.Namespace, serviceAccountKind, datadog.DeletionEvent)
	r.recordEvent(dda, event)
	return reconcile.Result{}, client.Delete(context.TODO(), serviceAccount)
}

type (
	createClusterRoleFunc       func(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, resourceName, agentVersion string) (reconcile.Result, error)
	updateIfNeedClusterRoleFunc func(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, resourceName, agentVersion string, clusterRole *rbacv1.ClusterRole) (reconcile.Result, error)
)

func (r *Reconciler) manageClusterRole(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRoleName, agentVersion string, createFunc createClusterRoleFunc, updateFunc updateIfNeedClusterRoleFunc, shouldCleanup bool) (reconcile.Result, error) {
	if shouldCleanup {
		return r.cleanupClusterRole(logger, dda, clusterRoleName)
	}

	clusterRole := &rbacv1.ClusterRole{}
	if err := r.client.Get(context.TODO(), types.NamespacedName{Name: clusterRoleName}, clusterRole); err != nil {
		if errors.IsNotFound(err) {
			return createFunc(logger, dda, clusterRoleName, agentVersion)
		} else if err != nil {
			return reconcile.Result{}, err
		}
	}

	return updateFunc(logger, dda, clusterRoleName, agentVersion, clusterRole)
}

type (
	createClusterRoleBindingFunc       func(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, name, agentVersion string) (reconcile.Result, error)
	updateIfNeedClusterRoleBindingFunc func(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, name, agentVersion string, clusterRole *rbacv1.ClusterRoleBinding) (reconcile.Result, error)
)

func (r *Reconciler) manageClusterRoleBinding(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRoleBindingName, agentVersion string, createFunc createClusterRoleBindingFunc, updateFunc updateIfNeedClusterRoleBindingFunc, shouldCleanup bool) (reconcile.Result, error) {
	if shouldCleanup {
		return r.cleanupClusterRoleBinding(logger, dda, clusterRoleBindingName)
	}

	clusterRoleBinding := &rbacv1.ClusterRoleBinding{}
	if err := r.client.Get(context.TODO(), types.NamespacedName{Name: clusterRoleBindingName}, clusterRoleBinding); err != nil {
		if errors.IsNotFound(err) {
			return createFunc(logger, dda, clusterRoleBindingName, agentVersion)
		} else if err != nil {
			return reconcile.Result{}, err
		}
	}

	return updateFunc(logger, dda, clusterRoleBindingName, agentVersion, clusterRoleBinding)
}

func (r *Reconciler) updateIfNeededClusterRoleBinding(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRoleBindingName, roleName, serviceAccountName, version string, clusterRoleBinding *rbacv1.ClusterRoleBinding) (reconcile.Result, error) {
	info := roleBindingInfo{
		name:               clusterRoleBindingName,
		roleName:           roleName,
		serviceAccountName: serviceAccountName,
	}
	newClusterRoleBinding := buildClusterRoleBinding(dda, info, version)
	return r.updateIfNeededClusterRoleBindingRaw(logger, dda, clusterRoleBinding, newClusterRoleBinding)
}

func (r *Reconciler) updateIfNeededClusterRoleBindingRaw(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRoleBinding, newClusterRoleBinding *rbacv1.ClusterRoleBinding) (reconcile.Result, error) {
	if !isClusterRolesBindingEqual(newClusterRoleBinding, clusterRoleBinding) {
		logger.V(1).Info("updateIfNeededClusterRoleBinding", "clusterRoleBinding.name", clusterRoleBinding.Name)
		// ClusterRoleBinding can't be updated, if we change the RoleRef in it, we need to delete and recreate
		if err := r.client.Delete(context.TODO(), clusterRoleBinding); err != nil {
			return reconcile.Result{}, err
		}
		if err := r.client.Create(context.TODO(), newClusterRoleBinding); err != nil {
			return reconcile.Result{}, err
		}
		event := buildEventInfo(newClusterRoleBinding.Name, newClusterRoleBinding.Namespace, clusterRoleKind, datadog.UpdateEvent)
		r.recordEvent(dda, event)
	}
	return reconcile.Result{}, nil
}

func (r *Reconciler) updateIfNeededClusterRole(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, clusterRole, newClusterRole *rbacv1.ClusterRole) (reconcile.Result, error) {
	if !isClusterRolesEqual(newClusterRole, clusterRole) {
		logger.V(1).Info("updateIfNeededClusterRole", "clusterRole.name", clusterRole.Name)
		if err := kubernetes.UpdateFromObject(context.TODO(), r.client, newClusterRole, clusterRole.ObjectMeta); err != nil {
			return reconcile.Result{}, err
		}
		event := buildEventInfo(newClusterRole.Name, newClusterRole.Namespace, clusterRoleKind, datadog.UpdateEvent)
		r.recordEvent(dda, event)
	}
	return reconcile.Result{}, nil
}

func (r *Reconciler) updateIfNeededRole(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, role, newRole *rbacv1.Role) (reconcile.Result, error) {
	if !isRolesEqual(newRole, role) {
		logger.V(1).Info("updateIfNeededRole", "role.name", role.Name)
		if err := kubernetes.UpdateFromObject(context.TODO(), r.client, newRole, role.ObjectMeta); err != nil {
			return reconcile.Result{}, err
		}
		event := buildEventInfo(newRole.Name, newRole.Namespace, roleKind, datadog.UpdateEvent)
		r.recordEvent(dda, event)
	}
	return reconcile.Result{}, nil
}

// isOwnerBasedOnLabels returns whether a DatadogAgent is the owner of a
// resource based on its labels.
// DatadogAgent objects are namespace-scoped. Some resources like cluster roles
// and cluster role bindings are not. This means that the DatadogAgent objects
// cannot be set as owner ref for those. For those objects, we can use their
// labels to know whether a DatadogAgent object owns them.
func isOwnerBasedOnLabels(dda *datadoghqv1alpha1.DatadogAgent, labels map[string]string) bool {
	isManagedByOperator := labels[kubernetes.AppKubernetesManageByLabelKey] == "datadog-operator"
	isPartOfDDA := labels[kubernetes.AppKubernetesPartOfLabelKey] == object.NewPartOfLabelValue(dda).String()
	return isManagedByOperator && isPartOfDDA
}

// rbacNamesForDda return the list of RBAC name that are used for cluster level RBAC
func rbacNamesForDda(dda *datadoghqv1alpha1.DatadogAgent, versionInfo *version.Info) []string {
	return []string{
		getAgentRbacResourcesName(dda),
		componentdca.GetClusterAgentRbacResourcesName(dda),
		getClusterChecksRunnerRbacResourcesName(dda),
		componentdca.GetHPAClusterRoleBindingName(dda),
		componentdca.GetExternalMetricsReaderClusterRoleName(dda, versionInfo),
		// kubestatemetrics_core can run on the DCA and the Runners
		kubernetesstatecore.GetKubeStateMetricsRBACResourceName(dda, common.ClusterAgentSuffix),
		kubernetesstatecore.GetKubeStateMetricsRBACResourceName(dda, common.ChecksRunnerSuffix),
		// Orchestrator can run on the DCA or the Runners
		getOrchestratorRBACResourceName(dda, common.ClusterAgentSuffix),
		getOrchestratorRBACResourceName(dda, common.ChecksRunnerSuffix),
	}
}

func isRolesEqual(a, b *rbacv1.Role) bool {
	return apiequality.Semantic.DeepEqual(a.Rules, b.Rules) && apiequality.Semantic.DeepEqual(a.ObjectMeta.OwnerReferences, b.ObjectMeta.OwnerReferences)
}

func isClusterRolesEqual(a, b *rbacv1.ClusterRole) bool {
	// Even if a ClusterRole should not contain DatadogAgent ownerref, we need to check it is the case to be able to remove the ownerref that might have added
	// by a previous Operator version.
	return apiequality.Semantic.DeepEqual(a.Rules, b.Rules) && apiequality.Semantic.DeepEqual(a.ObjectMeta.OwnerReferences, b.ObjectMeta.OwnerReferences)
}

func isClusterRolesBindingEqual(a, b *rbacv1.ClusterRoleBinding) bool {
	// Even if a ClusterRoleBinding should not contain DatadogAgent ownerref, we need to check it is the case to be able to remove the ownerref that might have added
	// by a previous Operator version.
	return apiequality.Semantic.DeepEqual(a.RoleRef, b.RoleRef) && apiequality.Semantic.DeepEqual(a.Subjects, b.Subjects) && apiequality.Semantic.DeepEqual(a.ObjectMeta.OwnerReferences, b.ObjectMeta.OwnerReferences)
}

func checkSecretBackendMultipleProvidersUsed(envVarList []corev1.EnvVar) bool {
	for _, envVar := range envVarList {
		if envVar.Name == apicommon.DDSecretBackendCommand && envVar.Value == secretBackendMultipleProvidersScript {
			return true
		}
	}
	return false
}
