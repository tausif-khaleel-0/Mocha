package fake

import commonv1 "github.com/DataDog/datadog-operator/apis/datadoghq/common/v1"

const (
	// AllContainers all containers container name
	AllContainers commonv1.AgentContainerName = "all"
)
