// Unless explicitly stated otherwise all files in this repository are licensed
// under the Apache License Version 2.0.
// This product includes software developed at Datadog (https://www.datadoghq.com/).
// Copyright 2016-present Datadog, Inc.

// Package testutils_test contains a set of unit-test helper functions
// to ease the creation of unit-test around the DatadogAgent CRD controller
package testutils_test
