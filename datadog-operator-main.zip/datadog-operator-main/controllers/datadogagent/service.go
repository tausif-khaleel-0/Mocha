// Unless explicitly stated otherwise all files in this repository are licensed
// under the Apache License Version 2.0.
// This product includes software developed at Datadog (https://www.datadoghq.com/).
// Copyright 2016-present Datadog, Inc.

package datadogagent

import (
	"context"

	"github.com/go-logr/logr"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/intstr"

	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	apicommon "github.com/DataDog/datadog-operator/apis/datadoghq/common"
	datadoghqv1alpha1 "github.com/DataDog/datadog-operator/apis/datadoghq/v1alpha1"
	componentdca "github.com/DataDog/datadog-operator/controllers/datadogagent/component/clusteragent"
	"github.com/DataDog/datadog-operator/controllers/datadogagent/object"
	"github.com/DataDog/datadog-operator/pkg/controller/utils/comparison"
	"github.com/DataDog/datadog-operator/pkg/controller/utils/datadog"
	"github.com/DataDog/datadog-operator/pkg/kubernetes"
	"github.com/DataDog/datadog-operator/pkg/kubernetes/rbac"
	"github.com/DataDog/datadog-operator/pkg/utils"
	apiregistrationv1 "k8s.io/kube-aggregator/pkg/apis/apiregistration/v1"
)

func (r *Reconciler) manageClusterAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	if !isClusterAgentEnabled(dda.Spec.ClusterAgent) {
		return r.cleanupClusterAgentService(dda)
	}

	serviceName := componentdca.GetClusterAgentServiceName(dda)
	service := &corev1.Service{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Namespace: dda.Namespace, Name: serviceName}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return r.createClusterAgentService(logger, dda)
		}
		return reconcile.Result{}, err
	}

	return r.updateIfNeededClusterAgentService(logger, dda, service)
}

func (r *Reconciler) createClusterAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	newService := componentdca.GetClusterAgentService(dda)
	return r.createService(logger, dda, newService)
}

func (r *Reconciler) updateIfNeededClusterAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentService *corev1.Service) (reconcile.Result, error) {
	newService := componentdca.GetClusterAgentService(dda)
	return r.updateIfNeededService(logger, dda, currentService, newService)
}

func (r *Reconciler) cleanupClusterAgentService(dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	serviceName := componentdca.GetClusterAgentServiceName(dda)
	return cleanupService(r.client, serviceName, dda.Namespace, dda)
}

func (r *Reconciler) manageMetricsServerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	if !isMetricsProviderEnabled(dda.Spec.ClusterAgent) {
		return r.cleanupMetricsServerService(dda)
	}

	serviceName := componentdca.GetMetricsServerServiceName(dda)
	service := &corev1.Service{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Namespace: dda.Namespace, Name: serviceName}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return r.createMetricsServerService(logger, dda)
		}
		return reconcile.Result{}, err
	}

	return r.updateIfNeededMetricsServerService(logger, dda, service)
}

func (r *Reconciler) manageMetricsServerAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	if !isMetricsProviderEnabled(dda.Spec.ClusterAgent) {
		return r.cleanupMetricsServerAPIService(logger, dda)
	}

	apiServiceName := componentdca.GetMetricsServerAPIServiceName()
	apiService := &apiregistrationv1.APIService{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Name: apiServiceName}, apiService)
	if err != nil {
		if errors.IsNotFound(err) {
			return r.createMetricsServerAPIService(logger, dda)
		}
		return reconcile.Result{}, err
	}

	return r.updateIfNeededMetricsServerAPIService(logger, dda, apiService)
}

func (r *Reconciler) manageAdmissionControllerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	if !isAdmissionControllerEnabled(dda.Spec.ClusterAgent) {
		return r.cleanupAdmissionControllerService(dda)
	}

	serviceName := getAdmissionControllerServiceName(dda)
	service := &corev1.Service{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Namespace: dda.Namespace, Name: serviceName}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return r.createAdmissionControllerService(logger, dda)
		}
		return reconcile.Result{}, err
	}

	return r.updateIfNeededAdmissionControllerService(logger, dda, service)
}

var testGitVersion string

func (r *Reconciler) manageAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	// Service Internal Traffic Policy exists in Kube 1.21 but it is enabled by default since 1.22
	gitVersion := ""
	if r.versionInfo != nil {
		gitVersion = r.versionInfo.GitVersion
	}
	if testGitVersion != "" {
		gitVersion = testGitVersion
	}

	forceLocalServiceEnable := dda.Spec.Agent.LocalService != nil && dda.Spec.Agent.LocalService.ForceLocalServiceEnable != nil && *dda.Spec.Agent.LocalService.ForceLocalServiceEnable
	if !utils.IsAboveMinVersion(gitVersion, "1.22-0") && !forceLocalServiceEnable {
		return r.cleanupAgentService(dda)
	}

	serviceName := getAgentServiceName(dda)
	service := &corev1.Service{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Namespace: dda.Namespace, Name: serviceName}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return r.createAgentService(logger, dda)
		}
		return reconcile.Result{}, err
	}

	return r.updateIfNeededAgentService(logger, dda, service)
}

func (r *Reconciler) createMetricsServerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	newService := newMetricsServerService(dda)
	return r.createService(logger, dda, newService)
}

func (r *Reconciler) createMetricsServerAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	newAPIService := newMetricsServerAPIService(dda)
	return r.createAPIService(logger, dda, newAPIService)
}

func (r *Reconciler) createAdmissionControllerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	newService := newAdmissionControllerService(dda)
	return r.createService(logger, dda, newService)
}

func (r *Reconciler) createAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	newService := newAgentService(dda)
	return r.createService(logger, dda, newService)
}

func (r *Reconciler) cleanupMetricsServerService(dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	serviceName := componentdca.GetMetricsServerServiceName(dda)
	return cleanupService(r.client, serviceName, dda.Namespace, dda)
}

func (r *Reconciler) cleanupMetricsServerAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	apiServiceName := componentdca.GetMetricsServerAPIServiceName()
	return r.cleanupAPIService(logger, apiServiceName, dda)
}

func (r *Reconciler) cleanupAdmissionControllerService(dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	serviceName := getAdmissionControllerServiceName(dda)
	return cleanupService(r.client, serviceName, dda.Namespace, dda)
}

func (r *Reconciler) cleanupAgentService(dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	serviceName := getAgentServiceName(dda)
	return cleanupService(r.client, serviceName, dda.Namespace, dda)
}

func (r *Reconciler) updateIfNeededMetricsServerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentService *corev1.Service) (reconcile.Result, error) {
	newService := newMetricsServerService(dda)
	return r.updateIfNeededService(logger, dda, currentService, newService)
}

func (r *Reconciler) updateIfNeededMetricsServerAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentAPIService *apiregistrationv1.APIService) (reconcile.Result, error) {
	newAPIService := newMetricsServerAPIService(dda)
	return r.updateIfNeededAPIService(logger, dda, currentAPIService, newAPIService)
}

func (r *Reconciler) updateIfNeededAdmissionControllerService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentService *corev1.Service) (reconcile.Result, error) {
	newService := newAdmissionControllerService(dda)
	return r.updateIfNeededService(logger, dda, currentService, newService)
}

func (r *Reconciler) updateIfNeededAgentService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentService *corev1.Service) (reconcile.Result, error) {
	newService := newAgentService(dda)
	return r.updateIfNeededService(logger, dda, currentService, newService)
}

func (r *Reconciler) createService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, newService *corev1.Service) (reconcile.Result, error) {
	if err := controllerutil.SetControllerReference(dda, newService, r.scheme); err != nil {
		return reconcile.Result{}, err
	}
	if err := r.client.Create(context.TODO(), newService); err != nil {
		return reconcile.Result{}, err
	}
	logger.Info("Created Service", "name", newService.Name)
	event := buildEventInfo(newService.Name, newService.Namespace, serviceKind, datadog.CreationEvent)
	r.recordEvent(dda, event)

	return reconcile.Result{Requeue: true}, nil
}

func (r *Reconciler) createAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, newAPIService *apiregistrationv1.APIService) (reconcile.Result, error) {
	if err := SetOwnerReference(dda, newAPIService, r.scheme); err != nil {
		return reconcile.Result{}, err
	}
	if err := r.client.Create(context.TODO(), newAPIService); err != nil {
		logger.Error(err, "failed to create APIService", "name", newAPIService.Name)
		return reconcile.Result{}, err
	}
	logger.Info("Created APIService", "name", newAPIService.Name)
	event := buildEventInfo(newAPIService.Name, newAPIService.Namespace, apiServiceKind, datadog.CreationEvent)
	r.recordEvent(dda, event)

	return reconcile.Result{Requeue: true}, nil
}

func cleanupService(client client.Client, name, namespace string, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	service := &corev1.Service{}
	err := client.Get(context.TODO(), types.NamespacedName{Namespace: namespace, Name: name}, service)
	if err != nil {
		if errors.IsNotFound(err) {
			return reconcile.Result{}, nil
		}
		return reconcile.Result{}, err
	}
	if !CheckOwnerReference(dda, service) {
		return reconcile.Result{}, nil
	}

	err = client.Delete(context.TODO(), service)
	return reconcile.Result{}, err
}

func (r *Reconciler) cleanupAPIService(logger logr.Logger, name string, dda *datadoghqv1alpha1.DatadogAgent) (reconcile.Result, error) {
	apiService := &apiregistrationv1.APIService{}
	err := r.client.Get(context.TODO(), types.NamespacedName{Name: name}, apiService)
	if err != nil {
		if errors.IsNotFound(err) {
			return reconcile.Result{}, nil
		}
		return reconcile.Result{}, err
	}

	// if the apiService object is not owner by the DatadogAgent resource
	// do not delete it.
	if !CheckOwnerReference(dda, apiService) {
		return reconcile.Result{}, nil
	}

	err = r.client.Delete(context.TODO(), apiService)
	if err != nil {
		logger.Error(err, "failed to delete APIService", "name", name)
	}
	logger.Info("Deleted APIService", "name", name)
	return reconcile.Result{}, err
}

func (r *Reconciler) updateIfNeededService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentService, newService *corev1.Service) (reconcile.Result, error) {
	result := reconcile.Result{}
	hash := newService.Annotations[apicommon.MD5AgentDeploymentAnnotationKey]
	if !comparison.IsSameSpecMD5Hash(hash, currentService.GetAnnotations()) {
		updatedService := currentService.DeepCopy()
		updatedService.Labels = newService.Labels
		updatedService.Annotations = newService.Annotations
		updatedService.Spec = newService.Spec
		// ClusterIP is an immutable field
		updatedService.Spec.ClusterIP = currentService.Spec.ClusterIP

		if err := kubernetes.UpdateFromObject(context.TODO(), r.client, newService, currentService.ObjectMeta); err != nil {
			return reconcile.Result{}, err
		}
		event := buildEventInfo(updatedService.Name, updatedService.Namespace, serviceKind, datadog.UpdateEvent)
		r.recordEvent(dda, event)
		logger.Info("Update Service", "name", newService.Name)

		result.Requeue = true
	}

	return result, nil
}

func (r *Reconciler) updateIfNeededAPIService(logger logr.Logger, dda *datadoghqv1alpha1.DatadogAgent, currentAPIService, newAPIService *apiregistrationv1.APIService) (reconcile.Result, error) {
	result := reconcile.Result{}
	hash := newAPIService.Annotations[apicommon.MD5AgentDeploymentAnnotationKey]
	if !comparison.IsSameSpecMD5Hash(hash, currentAPIService.GetAnnotations()) {
		updatedAPIService := currentAPIService.DeepCopy()
		updatedAPIService.Labels = newAPIService.Labels
		updatedAPIService.Annotations = newAPIService.Annotations
		updatedAPIService.Spec = newAPIService.Spec

		if err := kubernetes.UpdateFromObject(context.TODO(), r.client, newAPIService, currentAPIService.ObjectMeta); err != nil {
			return reconcile.Result{}, err
		}
		event := buildEventInfo(updatedAPIService.Name, updatedAPIService.Namespace, apiServiceKind, datadog.UpdateEvent)
		r.recordEvent(dda, event)
		logger.Info("Update APIService", "name", newAPIService.Name)

		result.Requeue = true
	}

	return result, nil
}

func newMetricsServerService(dda *datadoghqv1alpha1.DatadogAgent) *corev1.Service {
	labels := object.GetDefaultLabels(dda, apicommon.DefaultClusterAgentResourceSuffix, getClusterAgentVersion(dda))
	annotations := object.GetDefaultAnnotations(dda)

	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:        componentdca.GetMetricsServerServiceName(dda),
			Namespace:   dda.Namespace,
			Labels:      labels,
			Annotations: annotations,
		},
		Spec: corev1.ServiceSpec{
			Type: corev1.ServiceTypeClusterIP,
			Selector: map[string]string{
				apicommon.AgentDeploymentNameLabelKey:      dda.Name,
				apicommon.AgentDeploymentComponentLabelKey: apicommon.DefaultClusterAgentResourceSuffix,
			},
			Ports: []corev1.ServicePort{
				{
					Protocol:   corev1.ProtocolTCP,
					TargetPort: intstr.FromInt(int(getClusterAgentMetricsProviderPort(*dda.Spec.ClusterAgent.Config))),
					Port:       apicommon.DefaultMetricsServerServicePort,
				},
			},
			SessionAffinity: corev1.ServiceAffinityNone,
		},
	}
	_, _ = comparison.SetMD5DatadogAgentGenerationAnnotation(&service.ObjectMeta, &service.Spec)

	return service
}

func newMetricsServerAPIService(dda *datadoghqv1alpha1.DatadogAgent) *apiregistrationv1.APIService {
	labels := object.GetDefaultLabels(dda, apicommon.DefaultClusterAgentResourceSuffix, getClusterAgentVersion(dda))
	annotations := object.GetDefaultAnnotations(dda)

	port := int32(apicommon.DefaultMetricsServerServicePort)
	apiService := &apiregistrationv1.APIService{
		ObjectMeta: metav1.ObjectMeta{
			Name:        componentdca.GetMetricsServerAPIServiceName(),
			Labels:      labels,
			Annotations: annotations,
		},
		Spec: apiregistrationv1.APIServiceSpec{
			Service: &apiregistrationv1.ServiceReference{
				Name:      componentdca.GetMetricsServerServiceName(dda),
				Namespace: dda.Namespace,
				Port:      &port,
			},
			Version:               "v1beta1",
			InsecureSkipTLSVerify: true,
			Group:                 rbac.ExternalMetricsAPIGroup,
			GroupPriorityMinimum:  100,
			VersionPriority:       100,
		},
	}
	_, _ = comparison.SetMD5DatadogAgentGenerationAnnotation(&apiService.ObjectMeta, &apiService.Spec)

	return apiService
}

func newAdmissionControllerService(dda *datadoghqv1alpha1.DatadogAgent) *corev1.Service {
	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:        getAdmissionControllerServiceName(dda),
			Namespace:   dda.Namespace,
			Labels:      object.GetDefaultLabels(dda, apicommon.DefaultClusterAgentResourceSuffix, getClusterAgentVersion(dda)),
			Annotations: object.GetDefaultAnnotations(dda),
		},
		Spec: corev1.ServiceSpec{
			Type: corev1.ServiceTypeClusterIP,
			Selector: map[string]string{
				apicommon.AgentDeploymentNameLabelKey:      dda.Name,
				apicommon.AgentDeploymentComponentLabelKey: apicommon.DefaultClusterAgentResourceSuffix,
			},
			Ports: []corev1.ServicePort{
				{
					Protocol:   corev1.ProtocolTCP,
					TargetPort: intstr.FromInt(apicommon.DefaultAdmissionControllerTargetPort),
					Port:       apicommon.DefaultAdmissionControllerServicePort,
				},
			},
			SessionAffinity: corev1.ServiceAffinityNone,
		},
	}
	_, _ = comparison.SetMD5DatadogAgentGenerationAnnotation(&service.ObjectMeta, &service.Spec)

	return service
}

func newAgentService(dda *datadoghqv1alpha1.DatadogAgent) *corev1.Service {
	serviceInternalTrafficPolicy := corev1.ServiceInternalTrafficPolicyLocal

	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:        getAgentServiceName(dda),
			Namespace:   dda.Namespace,
			Labels:      object.GetDefaultLabels(dda, apicommon.DefaultAgentResourceSuffix, getAgentVersion(dda)),
			Annotations: object.GetDefaultAnnotations(dda),
		},
		Spec: corev1.ServiceSpec{
			Type: corev1.ServiceTypeClusterIP,
			Selector: map[string]string{
				apicommon.AgentDeploymentNameLabelKey:      dda.Name,
				apicommon.AgentDeploymentComponentLabelKey: apicommon.DefaultAgentResourceSuffix,
			},
			Ports: []corev1.ServicePort{
				{
					Protocol:   corev1.ProtocolUDP,
					TargetPort: intstr.FromInt(apicommon.DefaultDogstatsdPort),
					Port:       apicommon.DefaultDogstatsdPort,
					Name:       apicommon.DefaultDogstatsdPortName,
				},
			},
			SessionAffinity:       corev1.ServiceAffinityNone,
			InternalTrafficPolicy: &serviceInternalTrafficPolicy,
		},
	}

	if isAPMEnabled(&dda.Spec) {
		service.Spec.Ports = append(service.Spec.Ports,
			corev1.ServicePort{
				Protocol:   corev1.ProtocolTCP,
				TargetPort: intstr.FromInt(int(*dda.Spec.Agent.Apm.HostPort)),
				Port:       *dda.Spec.Agent.Apm.HostPort,
				Name:       apicommon.DefaultApmPortName,
			})
	}

	_, _ = comparison.SetMD5DatadogAgentGenerationAnnotation(&service.ObjectMeta, &service.Spec)

	return service
}
